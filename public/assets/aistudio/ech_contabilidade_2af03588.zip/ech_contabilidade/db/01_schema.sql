-- ============================================================
-- ECHpro – Schema base (Empresa + Plano de Contas + Lançamentos)
-- PGC-NIRF (Moçambique) + estrutura preparada para Folha de Salários
-- ============================================================

-- 0. EMPRESA (multi-empresa preparado)
CREATE TABLE IF NOT EXISTS empresa (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    nome            TEXT    NOT NULL,
    nuit            TEXT,                       -- NUIT (9 dígitos)
    endereco        TEXT,
    telefone        TEXT,
    email           TEXT,
    moeda           TEXT    NOT NULL DEFAULT 'MZN',
    activa          INTEGER NOT NULL DEFAULT 1,
    criado_em       TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- 1. PLANO DE CONTAS (PGC-NIRF parametrizável)
-- Árvore: Classe → Conta integradora → Conta de movimento
CREATE TABLE IF NOT EXISTS PlanoContas (
    CodigoConta             VARCHAR(20) PRIMARY KEY,   -- Ex: '1', '11', '111', '1111'
    Designacao              VARCHAR(150) NOT NULL,
    TipoConta               CHAR(1) NOT NULL,          -- 'A' = Analítica (movimento), 'I' = Integradora
    NaturezaPredominante    CHAR(1) NOT NULL,          -- 'D' = Devedora, 'C' = Credora
    Classe                  INTEGER NOT NULL,          -- 1 a 8
    Activa                  INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT CK_Natureza CHECK (NaturezaPredominante IN ('D', 'C')),
    CONSTRAINT CK_Tipo     CHECK (TipoConta IN ('A', 'I')),
    CONSTRAINT CK_Classe   CHECK (Classe BETWEEN 1 AND 8)
);

CREATE INDEX IF NOT EXISTS IX_PlanoContas_Classe ON PlanoContas(Classe);

-- 2. DIÁRIOS CONTÁBEIS
CREATE TABLE IF NOT EXISTS DiariosContabeis (
    IdDiario        INTEGER PRIMARY KEY AUTOINCREMENT,
    CodigoDiario    VARCHAR(5)  UNIQUE NOT NULL,      -- CX, VD, CP, OD, FS (Folha Salários)
    NomeDiario      VARCHAR(50) NOT NULL
);

-- Diários padrão
INSERT OR IGNORE INTO DiariosContabeis (CodigoDiario, NomeDiario) VALUES
    ('CX', 'Diário de Caixa'),
    ('VD', 'Diário de Vendas'),
    ('CP', 'Diário de Compras'),
    ('OD', 'Operações Diversas'),
    ('FS', 'Folha de Salários');

-- 3. CABEÇALHO DO LANÇAMENTO
CREATE TABLE IF NOT EXISTS CabecalhoLancamento (
    IdLancamento    INTEGER PRIMARY KEY AUTOINCREMENT,
    DataLancamento  DATE    NOT NULL,
    NumeroDocumento VARCHAR(30) NOT NULL,
    IdDiario        INTEGER NOT NULL,
    DescricaoGeral  TEXT,
    IdEmpresa       INTEGER NOT NULL DEFAULT 1,
    DataCriacao     TEXT    NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (IdDiario)  REFERENCES DiariosContabeis(IdDiario),
    FOREIGN KEY (IdEmpresa) REFERENCES empresa(id)
);

CREATE INDEX IF NOT EXISTS IX_Cabecalho_Data ON CabecalhoLancamento(DataLancamento);
CREATE INDEX IF NOT EXISTS IX_Cabecalho_Empresa ON CabecalhoLancamento(IdEmpresa);

-- 4. LINHAS DO LANÇAMENTO (Partidas Dobradas)
CREATE TABLE IF NOT EXISTS LinhasLancamento (
    IdLinha             INTEGER PRIMARY KEY AUTOINCREMENT,
    IdLancamento        INTEGER NOT NULL,
    CodigoConta         VARCHAR(20) NOT NULL,
    TipoMovimento       CHAR(1) NOT NULL,              -- 'D' ou 'C'
    Valor               DECIMAL(18,2) NOT NULL CHECK (Valor >= 0),
    HistoricoEspecifico TEXT,
    CONSTRAINT CK_TipoMovimento CHECK (TipoMovimento IN ('D', 'C')),
    FOREIGN KEY (IdLancamento) REFERENCES CabecalhoLancamento(IdLancamento) ON DELETE CASCADE,
    FOREIGN KEY (CodigoConta)  REFERENCES PlanoContas(CodigoConta)
);

CREATE INDEX IF NOT EXISTS IX_Linhas_Lancamento ON LinhasLancamento(IdLancamento);
CREATE INDEX IF NOT EXISTS IX_Linhas_Conta ON LinhasLancamento(CodigoConta);

-- 5. FUNCIONÁRIOS (base para Folha de Salários)
CREATE TABLE IF NOT EXISTS funcionario (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    id_empresa          INTEGER NOT NULL,
    nome                TEXT    NOT NULL,
    nuit                TEXT,
    bi_numero           TEXT,
    data_nascimento     DATE,
    data_admissao       DATE    NOT NULL,
    data_cessacao       DATE,
    cargo               TEXT,
    departamento        TEXT,
    salario_base        DECIMAL(18,2) NOT NULL DEFAULT 0,
    num_dependentes     INTEGER NOT NULL DEFAULT 0,
    inss_contribuinte   INTEGER NOT NULL DEFAULT 1,    -- 1 = contribui INSS
    activo              INTEGER NOT NULL DEFAULT 1,
    criado_em           TEXT    NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (id_empresa) REFERENCES empresa(id)
);

CREATE INDEX IF NOT EXISTS IX_funcionario_empresa ON funcionario(id_empresa);

-- 6. FOLHA DE SALÁRIOS (cabeçalho mensal)
CREATE TABLE IF NOT EXISTS folha_salario (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    id_empresa      INTEGER NOT NULL,
    ano             INTEGER NOT NULL,
    mes             INTEGER NOT NULL CHECK (mes BETWEEN 1 AND 12),
    estado          TEXT    NOT NULL DEFAULT 'rascunho', -- rascunho | processada | paga
    data_processamento TEXT,
    observacoes     TEXT,
    UNIQUE(id_empresa, ano, mes),
    FOREIGN KEY (id_empresa) REFERENCES empresa(id)
);

-- 7. LINHAS DA FOLHA (por funcionário)
CREATE TABLE IF NOT EXISTS folha_linha (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    id_folha            INTEGER NOT NULL,
    id_funcionario      INTEGER NOT NULL,
    salario_base        DECIMAL(18,2) NOT NULL,
    subsidios           DECIMAL(18,2) NOT NULL DEFAULT 0,
    descontos_outros    DECIMAL(18,2) NOT NULL DEFAULT 0,
    irps                DECIMAL(18,2) NOT NULL DEFAULT 0,  -- retenção IRPS
    inss_trabalhador    DECIMAL(18,2) NOT NULL DEFAULT 0,  -- 3%
    inss_empresa        DECIMAL(18,2) NOT NULL DEFAULT 0,  -- 4%
    liquido             DECIMAL(18,2) NOT NULL,
    FOREIGN KEY (id_folha)       REFERENCES folha_salario(id) ON DELETE CASCADE,
    FOREIGN KEY (id_funcionario) REFERENCES funcionario(id)
);

CREATE INDEX IF NOT EXISTS IX_folha_linha_folha ON folha_linha(id_folha);
