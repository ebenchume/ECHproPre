-- ============================================================
-- Carga Inicial das Contas Principais e Subcontas do PGC-NIRF
-- Estrutura hierárquica com códigos pontuados (ex: 2.4.6.1)
-- ============================================================

-- CLASSE 1: MEIOS FINANCEIROS LÍQUIDOS
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('1',       'Meios Financeiros Líquidos',                          'I', 'D', 1),
('1.1',     'Caixa',                                               'I', 'D', 1),
('1.1.1',   'Caixa Geral - Meticais',                              'A', 'D', 1),
('1.2',     'Bancos',                                              'I', 'D', 1),
('1.2.1',   'Depósitos à Ordem - Bancos Nacionais',                'A', 'D', 1);

-- CLASSE 2: CONTAS A RECEBER E A PAGAR
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('2',       'Contas a Receber e a Pagar',                          'I', 'D', 2),
('2.1',     'Clientes',                                            'I', 'D', 2),
('2.1.1',   'Clientes Nacionais',                                  'A', 'D', 2),
('2.2',     'Fornecedores',                                        'I', 'C', 2),
('2.2.1',   'Fornecedores Nacionais',                              'A', 'C', 2),
('2.4',     'Estado',                                              'I', 'C', 2),
('2.4.3',   'Imposto sobre o Valor Acrescentado (IVA)',            'I', 'D', 2),
('2.4.3.1', 'IVA - Suportado',                                     'A', 'D', 2),
('2.4.3.2', 'IVA - Dedutível',                                     'A', 'D', 2),
('2.4.3.3', 'IVA - Liquidado',                                     'A', 'C', 2),
('2.4.3.4', 'IVA - Apuramento',                                    'A', 'D', 2),
('2.4.5',   'Segurança Social (INSS)',                             'A', 'C', 2),
('2.4.6',   'Imposto sobre o Rendimento (IRPS/IRPC)',              'I', 'C', 2),
('2.4.6.1', 'IRPS - Retenções na Fonte (Trabalhadores)',           'A', 'C', 2),
('2.4.6.2', 'IRPC - Pagamentos por Conta',                         'A', 'D', 2),
('2.6',     'Pessoal',                                             'I', 'C', 2),
('2.6.1',   'Remunerações a Pagar',                                'A', 'C', 2);

-- CLASSE 3: INVENTÁRIOS E ACTIVOS BIOLÓGICOS
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('3',       'Inventários e Activos Biológicos',                    'I', 'D', 3),
('3.2',     'Mercadorias',                                         'A', 'D', 3);

-- CLASSE 4: INVESTIMENTOS (ACTIVOS NÃO CORRENTES)
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('4',       'Investimentos',                                       'I', 'D', 4),
('4.2',     'Activos Tangíveis (Imobilizado)',                     'A', 'D', 4);

-- CLASSE 5: CAPITAL PRÓPRIO E RESERVAS
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('5',       'Capital Próprio e Reservas',                          'I', 'C', 5),
('5.1',     'Capital Social',                                      'A', 'C', 5),
('5.9',     'Resultados Transitados',                              'A', 'C', 5);

-- CLASSE 6: GASTOS E PERDAS
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('6',       'Gastos e Perdas',                                     'I', 'D', 6),
('6.1',     'Custo das Mercadorias Vendidas e Matérias Consumidas','A', 'D', 6),
('6.2',     'Gastos com o Pessoal',                                'I', 'D', 6),
('6.2.1',   'Remunerações dos Órgãos Sociais',                     'A', 'D', 6),
('6.2.2',   'Ordenados e Salários do Pessoal',                     'A', 'D', 6),
('6.2.3',   'Encargos sobre as Remunerações (INSS Empresa 4%)',    'A', 'D', 6),
('6.3',     'Fornecimentos e Serviços de Terceiros (FST)',         'A', 'D', 6);

-- CLASSE 7: RENDIMENTOS E GANHOS
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('7',       'Rendimentos e Ganhos',                                'I', 'C', 7),
('7.1',     'Vendas',                                              'A', 'C', 7),
('7.2',     'Prestações de Serviços',                              'A', 'C', 7);

-- CLASSE 8: RESULTADOS
INSERT OR IGNORE INTO PlanoContas (CodigoConta, Designacao, TipoConta, NaturezaPredominante, Classe) VALUES
('8',       'Resultados',                                          'I', 'D', 8),
('8.1',     'Resultados Operacionais',                             'A', 'D', 8),
('8.2',     'Resultados Financeiros',                              'A', 'D', 8),
('8.3',     'Resultados Correntes',                                'A', 'D', 8),
('8.8',     'Resultado Líquido do Exercício',                      'A', 'D', 8);
