// Arranque do ECHpro:
//   1) modos de linha de comandos usados pelo instalador (--init-db, --backup), sem interface;
//   2) cria/migra a base de dados;
//   3) regista os serviços (injeção de dependências);
//   4) licença válida -> janela principal; caso contrário -> janela de ativação.
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using ECHpro.App.ViewModels;
using ECHpro.App.Views;
using ECHpro.Data;
using ECHpro.Licensing;

namespace ECHpro.App;

public partial class App : Application
{
    /// <summary>Contentor de serviços (usado pelas páginas, ex.: PayrollPage).</summary>
    public static IServiceProvider Services { get; private set; } = null!;

    private Window? _window;   // referência mantida para a janela não ser recolhida pelo GC

    public App()
    {
        InitializeComponent();
        UnhandledException += (_, e) => Log(e.Exception);
    }

    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        var cli = Environment.GetCommandLineArgs();
        bool modoSilencioso = cli.Contains("--init-db") || cli.Contains("--backup");

        try
        {
            if (cli.Contains("--init-db")) { DatabaseMaintenance.EnsureCreated(); Exit(); return; }
            if (cli.Contains("--backup"))  { DatabaseMaintenance.Backup();        Exit(); return; }

            DatabaseMaintenance.EnsureCreated();
            Services = ConfigurarServicos();
        }
        catch (Exception ex)
        {
            Log(ex);
            if (modoSilencioso) { Environment.ExitCode = 1; Exit(); return; }
            MostrarErroFatal($"Não foi possível iniciar o ECHpro.\n\n{ex.Message}\n\nDetalhes em ProgramData\\ECHpro\\logs.");
            return;
        }

        if (LicenseService.IsActivated())
            AbrirJanelaPrincipal();
        else
        {
            var ativacao = new ActivationWindow();
            ativacao.LicenseActivated += (_, _) => { AbrirJanelaPrincipal(); ativacao.Close(); };
            _window = ativacao;
            ativacao.Activate();
        }
    }

    private void AbrirJanelaPrincipal()
    {
        var main = new MainWindow();
        _window = main;
        main.Activate();
    }

    private static IServiceProvider ConfigurarServicos()
    {
        var sc = new ServiceCollection();

        // Uma ligação SQLite para toda a aplicação desktop (WAL + chaves estrangeiras activas).
        sc.AddSingleton(_ => ConfigBaseDados.AbrirLigacao());

        // Serviços de domínio
        sc.AddTransient<ECHpro.Data.Services.LancamentoService>();
        sc.AddTransient<ECHpro.Data.Services.FechoExercicioService>();
        sc.AddTransient<ECHpro.Data.Services.DemonstracaoResultadosService>();

        sc.AddTransient(sp =>
        {
            var con = sp.GetRequiredService<SqliteConnection>();
            return new PayrollViewModel(con, EmpresaActivaId(con));
        });

        return sc.BuildServiceProvider();
    }

    /// <summary>Primeira empresa registada (0 se ainda não existir nenhuma – falta o assistente de configuração).</summary>
    private static int EmpresaActivaId(SqliteConnection con)
    {
        using var cmd = con.CreateCommand();
        cmd.CommandText = "SELECT id FROM empresa ORDER BY id LIMIT 1";
        return cmd.ExecuteScalar() is { } v ? Convert.ToInt32(v) : 0;
    }

    private void MostrarErroFatal(string mensagem)
    {
        _window = new Window
        {
            Title = "ECHpro – Erro",
            Content = new TextBlock { Text = mensagem, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(24) }
        };
        _window.Activate();
    }

    private static void Log(Exception ex)
    {
        try
        {
            var pasta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ECHpro", "logs");
            Directory.CreateDirectory(pasta);
            File.AppendAllText(Path.Combine(pasta, $"erro_{DateTime.Now:yyyyMMdd}.log"),
                               $"[{DateTime.Now:HH:mm:ss}] {ex}\n\n");
        }
        catch { /* o registo nunca deve causar um novo erro */ }
    }
}
