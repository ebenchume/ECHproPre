using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;
using ECHpro.App.ViewModels;
using Microsoft.Extensions.DependencyInjection;

namespace ECHpro.App.Views;

public sealed partial class PayrollPage : Page
{
    private PayrollViewModel? _vm;

    public PayrollPage()
    {
        InitializeComponent();
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);

        _vm = App.Services.GetRequiredService<PayrollViewModel>();
        LvFuncionarios.ItemsSource = _vm.Funcionarios;

        NbAno.Value = _vm.Ano;
        CbMes.SelectedIndex = _vm.Mes - 1;
        ActualizarTotaisUI();
    }

    private void BtnCarregar_Click(object sender, RoutedEventArgs e)
    {
        if (_vm is null) return;
        _vm.Ano = (int)NbAno.Value;
        _vm.Mes = CbMes.SelectedIndex + 1;
        _vm.CarregarFuncionarios();
        ActualizarTotaisUI();
    }

    private void BtnRecalcular_Click(object sender, RoutedEventArgs e)
    {
        _vm?.RecalcularTudo();
        ActualizarTotaisUI();
    }

    private async void BtnProcessar_Click(object sender, RoutedEventArgs e)
    {
        if (_vm is null) return;

        var dialog = new ContentDialog
        {
            Title = "Processar Folha",
            Content = $"Confirma o processamento da folha de {_vm.Mes:00}/{_vm.Ano}?\n\nEsta acção grava os valores calculados.",
            PrimaryButtonText = "Processar",
            CloseButtonText = "Cancelar",
            DefaultButton = ContentDialogButton.Primary,
            XamlRoot = this.XamlRoot
        };

        var result = await dialog.ShowAsync();
        if (result != ContentDialogResult.Primary) return;

        // TODO: gravar na tabela folha_salario + folha_linha
        _vm.Estado = "processada";
        TxtEstado.Text = "Estado: processada";
    }

    private void ActualizarTotaisUI()
    {
        if (_vm is null) return;
        TxtTotalLiquido.Text = $"{_vm.TotalLiquido:N2} MT";
        TxtTotalIrps.Text    = $"{_vm.TotalIrps:N2} MT";
        TxtTotalInss.Text    = $"{_vm.TotalInssEmpresa:N2} MT";
        TxtEstado.Text       = $"Estado: {_vm.Estado}";
    }
}
