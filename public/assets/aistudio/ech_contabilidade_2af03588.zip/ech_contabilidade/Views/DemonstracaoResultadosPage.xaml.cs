using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using Microsoft.Extensions.DependencyInjection;
using ECHpro.Data.Models;
using ECHpro.Data.Services;
using Windows.UI;

namespace ECHpro.App.Views;

public sealed partial class DemonstracaoResultadosPage : Page
{
    private DemonstracaoResultadosService? _servico;
    private List<LinhaDRE> _linhas = new();

    public DemonstracaoResultadosPage()
    {
        InitializeComponent();
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);
        _servico = App.Services.GetRequiredService<DemonstracaoResultadosService>();
        NbAno.Value = DateTime.Now.Year;
        Gerar();
    }

    private void BtnGerar_Click(object sender, RoutedEventArgs e) => Gerar();

    private void Gerar()
    {
        if (_servico is null) return;

        int ano = (int)NbAno.Value;
        _linhas = _servico.GerarDre(ano);

        TxtPeriodo.Text = $"Período: Janeiro a Dezembro de {ano} | Valores expressos em Meticais (MT)";
        LvDre.ItemsSource = null;
        LvDre.ItemsSource = _linhas;
        BtnExportar.IsEnabled = _linhas.Count > 0;

        // Destacar subtotais visualmente (após o binding)
        LvDre.ContainerContentChanging += OnContainerContentChanging;
    }

    private void OnContainerContentChanging(ListViewBase sender, ContainerContentChangingEventArgs args)
    {
        if (args.Item is not LinhaDRE linha) return;
        if (args.ItemContainer is not ListViewItem container) return;

        if (linha.IsTotal)
        {
            container.Background = new SolidColorBrush(Color.FromArgb(40, 0, 120, 212));
            container.FontWeight = Microsoft.UI.Text.FontWeights.Bold;
        }
        else if (linha.IsSubtotal)
        {
            container.Background = new SolidColorBrush(Color.FromArgb(25, 244, 247, 249));
            container.FontWeight = Microsoft.UI.Text.FontWeights.SemiBold;
        }
        else
        {
            container.Background = null;
            container.FontWeight = Microsoft.UI.Text.FontWeights.Normal;
        }
    }

    private async void BtnExportar_Click(object sender, RoutedEventArgs e)
    {
        // Placeholder – futura exportação para PDF / Excel
        var dialog = new ContentDialog
        {
            Title = "Exportar DRE",
            Content = "A exportação para PDF/Excel será implementada em breve.",
            CloseButtonText = "OK",
            XamlRoot = this.XamlRoot
        };
        await dialog.ShowAsync();
    }
}
