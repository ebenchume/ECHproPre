using Microsoft.UI.Xaml;
using ECHpro.Licensing;

namespace ECHpro.App.Views;

public sealed partial class ActivationWindow : Window
{
    public event EventHandler? LicenseActivated;

    public ActivationWindow()
    {
        InitializeComponent();
    }

    private void BtnActivar_Click(object sender, RoutedEventArgs e)
    {
        var key = TbLicenseKey.Text?.Trim() ?? "";
        if (LicenseService.Activate(key))
        {
            TxtErro.Visibility = Visibility.Collapsed;
            LicenseActivated?.Invoke(this, EventArgs.Empty);
        }
        else
        {
            TxtErro.Text = "Chave inválida. A chave deve ter pelo menos 16 caracteres.";
            TxtErro.Visibility = Visibility.Visible;
        }
    }
}
