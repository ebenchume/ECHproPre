// Serviço simples de licenciamento.
// Versão inicial: ficheiro de activação em ProgramData\ECHpro\license.key
// (mais tarde pode evoluir para validação online / hardware ID).
namespace ECHpro.Licensing;

public static class LicenseService
{
    private static readonly string LicensePath =
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "ECHpro", "license.key");

    public static bool IsActivated()
    {
        try
        {
            if (!File.Exists(LicensePath)) return false;
            var key = File.ReadAllText(LicensePath).Trim();
            // Aceita qualquer chave com pelo menos 16 caracteres (placeholder)
            return key.Length >= 16;
        }
        catch
        {
            return false;
        }
    }

    public static bool Activate(string licenseKey)
    {
        if (string.IsNullOrWhiteSpace(licenseKey) || licenseKey.Trim().Length < 16)
            return false;

        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LicensePath)!);
            File.WriteAllText(LicensePath, licenseKey.Trim());
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static void Deactivate()
    {
        try { if (File.Exists(LicensePath)) File.Delete(LicensePath); } catch { }
    }
}
