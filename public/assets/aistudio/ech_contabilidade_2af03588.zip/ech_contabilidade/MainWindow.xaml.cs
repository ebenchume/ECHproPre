using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using ECHpro.App.Views;

namespace ECHpro.App;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        (AppWindow.Presenter as OverlappedPresenter)?.Maximize();
        Nav.SelectedItem = Nav.MenuItems[0];
    }

    private void Nav_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        if (args.SelectedItem is not NavigationViewItem item) return;

        switch (item.Tag as string)
        {
            case "payroll":
                ContentFrame.Navigate(typeof(PayrollPage));
                break;
            case "dre":
                ContentFrame.Navigate(typeof(DemonstracaoResultadosPage));
                break;
        }
    }
}
