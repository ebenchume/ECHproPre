// Demonstração de Resultados por Natureza (PGC-NIRF).
// Constrói a DRE a partir dos saldos das Classes 6, 7 e 8.
using ECHpro.Data.Models;

namespace ECHpro.Data.Services;

public sealed class DemonstracaoResultadosService
{
    private readonly LancamentoService _lancamentos;

    public DemonstracaoResultadosService(LancamentoService lancamentos)
    {
        _lancamentos = lancamentos;
    }

    /// <summary>
    /// Gera a Demonstração de Resultados por Natureza para o período indicado.
    /// </summary>
    public List<LinhaDRE> GerarDre(int ano, int? idEmpresa = 1, DateTime? dataAte = null)
    {
        dataAte ??= new DateTime(ano, 12, 31);

        var saldos = _lancamentos.ObterSaldos(
            idEmpresa: idEmpresa,
            classe: null,
            apenasMovimento: true,
            dataAte: dataAte);

        // Mapear saldos por código de conta
        var mapa = saldos.ToDictionary(s => s.CodigoConta, s => s.SaldoActual);

        decimal S(string codigo) => mapa.TryGetValue(codigo, out var v) ? Math.Abs(v) : 0m;

        // --- Rubricas principais (estrutura simplificada PGC-NIRF) ---
        decimal vendas             = S("7.1");
        decimal prestacoesServicos = S("7.2");
        decimal volumeNegocios     = vendas + prestacoesServicos;

        decimal cmv                = S("6.1");
        decimal margemBruta        = volumeNegocios - cmv;

        decimal gastosPessoal      = S("6.2.1") + S("6.2.2") + S("6.2.3");
        decimal fst                = S("6.3");
        decimal totalGastos        = gastosPessoal + fst + cmv;

        decimal resultadoOperacional = volumeNegocios - totalGastos;

        // IRPC (se já tiver sido lançado no fecho)
        decimal irpc             = S("8.8");
        decimal resultadoLiquido = resultadoOperacional - irpc;

        var linhas = new List<LinhaDRE>
        {
            // --- Volume de Negócios ---
            new() { Rubrica = "1. Vendas e prestações de serviços" },
            new() { Rubrica = "   Vendas",                     Nota = "7.1", ValorAtual = vendas },
            new() { Rubrica = "   Prestações de serviços",     Nota = "7.2", ValorAtual = prestacoesServicos },
            new() { Rubrica = "Volume de negócios",            ValorAtual = volumeNegocios, IsSubtotal = true },

            // --- Custo das mercadorias ---
            new() { Rubrica = "2. Custo das mercadorias vendidas e matérias consumidas",
                    Nota = "6.1", ValorAtual = cmv > 0 ? -cmv : 0 },

            new() { Rubrica = "Margem bruta", ValorAtual = margemBruta, IsSubtotal = true },

            // --- Gastos operacionais ---
            new() { Rubrica = "3. Gastos com o pessoal" },
            new() { Rubrica = "   Remunerações dos órgãos sociais", Nota = "6.2.1",
                    ValorAtual = S("6.2.1") > 0 ? -S("6.2.1") : 0 },
            new() { Rubrica = "   Ordenados e salários",            Nota = "6.2.2",
                    ValorAtual = S("6.2.2") > 0 ? -S("6.2.2") : 0 },
            new() { Rubrica = "   Encargos sobre remunerações (INSS)", Nota = "6.2.3",
                    ValorAtual = S("6.2.3") > 0 ? -S("6.2.3") : 0 },
            new() { Rubrica = "Total gastos com o pessoal",
                    ValorAtual = gastosPessoal > 0 ? -gastosPessoal : 0, IsSubtotal = true },

            new() { Rubrica = "4. Fornecimentos e serviços de terceiros",
                    Nota = "6.3", ValorAtual = fst > 0 ? -fst : 0 },

            // --- Resultado operacional ---
            new() { Rubrica = "Resultado operacional",
                    ValorAtual = resultadoOperacional, IsSubtotal = true, IsTotal = true },

            // --- Imposto e resultado líquido ---
            new() { Rubrica = "5. Imposto sobre o rendimento (IRPC)",
                    ValorAtual = irpc > 0 ? -irpc : 0 },

            new() { Rubrica = "Resultado líquido do período",
                    ValorAtual = resultadoLiquido, IsSubtotal = true, IsTotal = true },
        };

        return linhas;
    }
}
