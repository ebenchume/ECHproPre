// Fecho de exercício contabilístico (PGC-NIRF).
// Transfere saldos das Classes 6 (Gastos) e 7 (Rendimentos) para a Classe 8
// e calcula o IRPC provisório (taxa padrão 32% em Moçambique).
using Microsoft.Data.Sqlite;
using ECHpro.Data.Models;

namespace ECHpro.Data.Services;

public sealed class FechoExercicioService
{
    private readonly SqliteConnection _con;
    private readonly LancamentoService _lancamentos;

    /// <summary>Taxa padrão de IRPC em Moçambique (pode ser parametrizada por empresa).</summary>
    public decimal TaxaIrpc { get; set; } = 0.32m;

    public FechoExercicioService(SqliteConnection con, LancamentoService lancamentos)
    {
        _con = con;
        _lancamentos = lancamentos;
    }

    /// <summary>
    /// Executa o fecho do exercício fiscal.
    /// 1. Zera contas de Classe 6 (crédito) e Classe 7 (débito)
    /// 2. Transfere os totais para 8.1 – Resultados Operacionais
    /// 3. Se houver lucro, calcula IRPC e lança contra 2.4.6.2 / conta de imposto
    /// </summary>
    public ResultadoFecho ExecutarFechoExercicio(int anoFiscal, int idEmpresa = 1)
    {
        var dataLimite = new DateTime(anoFiscal, 12, 31);

        // 1. Obter saldos das Classes 6 e 7 até 31/Dez
        var saldos = _lancamentos.ObterSaldos(
            idEmpresa: idEmpresa,
            classe: null,
            apenasMovimento: true,
            dataAte: dataLimite);

        var contasClasse6 = saldos.Where(c => c.Classe == 6 && c.SaldoActual != 0).ToList();
        var contasClasse7 = saldos.Where(c => c.Classe == 7 && c.SaldoActual != 0).ToList();

        if (contasClasse6.Count == 0 && contasClasse7.Count == 0)
            throw new InvalidOperationException(
                $"Não existem saldos nas Classes 6 ou 7 para o exercício {anoFiscal}.");

        var linhas = new List<LinhaLancamentoModel>();
        decimal totalGastos = 0;
        decimal totalRendimentos = 0;

        // 2a. Zerar contas de Gasto (Classe 6) → CRÉDITO
        foreach (var conta in contasClasse6)
        {
            var valor = Math.Abs(conta.SaldoActual);
            linhas.Add(new LinhaLancamentoModel
            {
                CodigoConta = conta.CodigoConta,
                TipoMovimento = "C",
                Valor = valor,
                HistoricoEspecifico = $"Fecho de Exercício {anoFiscal} – zerar {conta.Designacao}"
            });
            totalGastos += valor;
        }

        // 2b. Zerar contas de Rendimento (Classe 7) → DÉBITO
        foreach (var conta in contasClasse7)
        {
            var valor = Math.Abs(conta.SaldoActual);
            linhas.Add(new LinhaLancamentoModel
            {
                CodigoConta = conta.CodigoConta,
                TipoMovimento = "D",
                Valor = valor,
                HistoricoEspecifico = $"Fecho de Exercício {anoFiscal} – zerar {conta.Designacao}"
            });
            totalRendimentos += valor;
        }

        // 3. Contrapartidas na conta 8.1 – Resultados Operacionais
        if (totalGastos > 0)
        {
            linhas.Add(new LinhaLancamentoModel
            {
                CodigoConta = "8.1",
                TipoMovimento = "D",
                Valor = totalGastos,
                HistoricoEspecifico = $"Transferência de Gastos – Exercício {anoFiscal}"
            });
        }

        if (totalRendimentos > 0)
        {
            linhas.Add(new LinhaLancamentoModel
            {
                CodigoConta = "8.1",
                TipoMovimento = "C",
                Valor = totalRendimentos,
                HistoricoEspecifico = $"Transferência de Rendimentos – Exercício {anoFiscal}"
            });
        }

        // 4. Cálculo do IRPC (se houver lucro antes de imposto)
        decimal lucroAntesImposto = totalRendimentos - totalGastos;
        decimal impostoDevido = 0;

        if (lucroAntesImposto > 0)
        {
            impostoDevido = Math.Round(lucroAntesImposto * TaxaIrpc, 2);

            // Débito em 8.8 (ou conta de imposto sobre o rendimento) – simplificado
            // Crédito em 2.4.6.2 (IRPC – Pagamentos por Conta / a pagar)
            // Nota: em implementação completa usa-se conta específica de "Imposto sobre o rendimento"
            linhas.Add(new LinhaLancamentoModel
            {
                CodigoConta = "8.8",
                TipoMovimento = "D",
                Valor = impostoDevido,
                HistoricoEspecifico = $"IRPC {TaxaIrpc:P0} sobre lucro de {lucroAntesImposto:N2} MT – Exercício {anoFiscal}"
            });

            linhas.Add(new LinhaLancamentoModel
            {
                CodigoConta = "2.4.6.2",
                TipoMovimento = "C",
                Valor = impostoDevido,
                HistoricoEspecifico = $"IRPC a pagar – Exercício {anoFiscal}"
            });
        }

        // 5. Validar e gravar o lançamento de fecho
        if (!_lancamentos.ValidarPartidaDobrada(linhas))
            throw new InvalidOperationException(
                "Partida dobrada inválida no lançamento de fecho. Verifique os saldos das Classes 6 e 7.");

        // Diário OD (Operações Diversas) – IdDiario = 4 no seed actual
        int idDiarioOd = ObterIdDiario("OD");

        var cabecalho = new CabecalhoLancamentoModel
        {
            DataLancamento = dataLimite,
            NumeroDocumento = $"FECHO-{anoFiscal}",
            IdDiario = idDiarioOd,
            DescricaoGeral = $"Fecho de Exercício {anoFiscal} – Transferência Classes 6/7 → 8",
            IdEmpresa = idEmpresa,
            Linhas = linhas
        };

        int idLancamento = _lancamentos.Gravar(cabecalho);

        return new ResultadoFecho
        {
            IdLancamento = idLancamento,
            AnoFiscal = anoFiscal,
            TotalGastos = totalGastos,
            TotalRendimentos = totalRendimentos,
            LucroAntesImposto = lucroAntesImposto,
            IrpcCalculado = impostoDevido,
            ResultadoLiquido = lucroAntesImposto - impostoDevido,
            ContasZeradas = contasClasse6.Count + contasClasse7.Count
        };
    }

    private int ObterIdDiario(string codigo)
    {
        using var cmd = _con.CreateCommand();
        cmd.CommandText = "SELECT IdDiario FROM DiariosContabeis WHERE CodigoDiario = $c";
        cmd.Parameters.AddWithValue("$c", codigo);
        var id = cmd.ExecuteScalar();
        if (id is null)
            throw new InvalidOperationException($"Diário '{codigo}' não encontrado. Execute as migrações da base de dados.");
        return Convert.ToInt32(id);
    }
}

/// <summary>Resultado devolvido após o fecho de exercício.</summary>
public sealed class ResultadoFecho
{
    public int IdLancamento { get; set; }
    public int AnoFiscal { get; set; }
    public decimal TotalGastos { get; set; }
    public decimal TotalRendimentos { get; set; }
    public decimal LucroAntesImposto { get; set; }
    public decimal IrpcCalculado { get; set; }
    public decimal ResultadoLiquido { get; set; }
    public int ContasZeradas { get; set; }
}
