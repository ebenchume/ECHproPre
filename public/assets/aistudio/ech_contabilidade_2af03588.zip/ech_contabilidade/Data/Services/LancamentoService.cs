// Serviço de lançamentos contábeis.
// Garante o rigor das partidas dobradas e grava cabeçalho + linhas numa transação.
using Microsoft.Data.Sqlite;
using ECHpro.Data.Models;

namespace ECHpro.Data.Services;

public sealed class LancamentoService
{
    private readonly SqliteConnection _con;

    public LancamentoService(SqliteConnection con)
    {
        _con = con;
    }

    /// <summary>
    /// Valida se a soma dos Débitos é igual à soma dos Créditos
    /// (tolerância de 0,01 MT para arredondamentos de centavos).
    /// </summary>
    public bool ValidarPartidaDobrada(List<LinhaLancamentoModel> linhas)
    {
        if (linhas is null || linhas.Count == 0)
            return false;

        decimal totalDebito = 0;
        decimal totalCredito = 0;

        foreach (var linha in linhas)
        {
            if (linha.TipoMovimento == "D")
                totalDebito += linha.Valor;
            else if (linha.TipoMovimento == "C")
                totalCredito += linha.Valor;
            else
                return false; // tipo inválido
        }

        // Compara os totais admitindo uma margem mínima para arredondamentos de centavos (MT)
        return Math.Abs(totalDebito - totalCredito) < 0.01m;
    }

    /// <summary>
    /// Grava um lançamento completo (cabeçalho + linhas) numa única transação.
    /// Lança InvalidOperationException se a partida dobrada não fechar.
    /// </summary>
    public int Gravar(CabecalhoLancamentoModel cabecalho)
    {
        if (cabecalho.Linhas is null || cabecalho.Linhas.Count < 2)
            throw new InvalidOperationException("Um lançamento precisa de pelo menos duas linhas.");

        if (!ValidarPartidaDobrada(cabecalho.Linhas))
            throw new InvalidOperationException(
                "Partida dobrada inválida: o total de Débitos não é igual ao total de Créditos.");

        // Verifica se todas as contas são de movimento (TipoConta = 'A')
        foreach (var linha in cabecalho.Linhas)
        {
            if (!ContaEDeMovimento(linha.CodigoConta))
                throw new InvalidOperationException(
                    $"A conta {linha.CodigoConta} não é de movimento (analítica).");
        }

        using var tx = _con.BeginTransaction();
        try
        {
            int idLancamento;

            using (var cmd = _con.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO CabecalhoLancamento
                        (DataLancamento, NumeroDocumento, IdDiario, DescricaoGeral, IdEmpresa)
                    VALUES
                        ($data, $doc, $diario, $desc, $empresa);
                    SELECT last_insert_rowid();";
                cmd.Parameters.AddWithValue("$data", cabecalho.DataLancamento.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("$doc", cabecalho.NumeroDocumento);
                cmd.Parameters.AddWithValue("$diario", cabecalho.IdDiario);
                cmd.Parameters.AddWithValue("$desc", (object?)cabecalho.DescricaoGeral ?? DBNull.Value);
                cmd.Parameters.AddWithValue("$empresa", cabecalho.IdEmpresa);
                idLancamento = Convert.ToInt32(cmd.ExecuteScalar());
            }

            foreach (var linha in cabecalho.Linhas)
            {
                using var cmd = _con.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO LinhasLancamento
                        (IdLancamento, CodigoConta, TipoMovimento, Valor, HistoricoEspecifico)
                    VALUES
                        ($id, $conta, $tipo, $valor, $hist)";
                cmd.Parameters.AddWithValue("$id", idLancamento);
                cmd.Parameters.AddWithValue("$conta", linha.CodigoConta);
                cmd.Parameters.AddWithValue("$tipo", linha.TipoMovimento);
                cmd.Parameters.AddWithValue("$valor", linha.Valor);
                cmd.Parameters.AddWithValue("$hist", (object?)linha.HistoricoEspecifico ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();
            return idLancamento;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    /// <summary>
    /// Obtém o saldo actual de uma conta (Débitos − Créditos ou vice-versa conforme a natureza).
    /// </summary>
    public decimal ObterSaldoConta(string codigoConta, int? idEmpresa = null)
    {
        using var cmd = _con.CreateCommand();
        cmd.CommandText = @"
            SELECT
                COALESCE(SUM(CASE WHEN l.TipoMovimento = 'D' THEN l.Valor ELSE 0 END), 0) AS Debitos,
                COALESCE(SUM(CASE WHEN l.TipoMovimento = 'C' THEN l.Valor ELSE 0 END), 0) AS Creditos,
                p.NaturezaPredominante
            FROM LinhasLancamento l
            INNER JOIN CabecalhoLancamento c ON c.IdLancamento = l.IdLancamento
            INNER JOIN PlanoContas p ON p.CodigoConta = l.CodigoConta
            WHERE l.CodigoConta = $conta
              AND ($empresa IS NULL OR c.IdEmpresa = $empresa)";
        cmd.Parameters.AddWithValue("$conta", codigoConta);
        cmd.Parameters.AddWithValue("$empresa", (object?)idEmpresa ?? DBNull.Value);

        using var r = cmd.ExecuteReader();
        if (!r.Read()) return 0m;

        var debitos = r.GetDecimal(0);
        var creditos = r.GetDecimal(1);
        var natureza = r.GetString(2);

        // Conta de natureza Devedora: saldo = Débitos − Créditos
        // Conta de natureza Credora:  saldo = Créditos − Débitos
        return natureza == "D" ? debitos - creditos : creditos - debitos;
    }

    /// <summary>
    /// Lista o saldo de todas as contas (ou filtradas por classe / só movimento).
    /// Usado no extrato de contas / balancete.
    /// </summary>
    public List<SaldoContaModel> ObterSaldos(
        int? idEmpresa = null,
        int? classe = null,
        bool apenasMovimento = true,
        DateTime? dataAte = null)
    {
        var lista = new List<SaldoContaModel>();

        using var cmd = _con.CreateCommand();
        cmd.CommandText = @"
            SELECT
                p.CodigoConta,
                p.Designacao,
                p.TipoConta,
                p.NaturezaPredominante,
                p.Classe,
                COALESCE(SUM(CASE WHEN l.TipoMovimento = 'D' THEN l.Valor ELSE 0 END), 0) AS TotalDebito,
                COALESCE(SUM(CASE WHEN l.TipoMovimento = 'C' THEN l.Valor ELSE 0 END), 0) AS TotalCredito,
                CASE
                    WHEN p.NaturezaPredominante = 'D' THEN
                        COALESCE(SUM(CASE WHEN l.TipoMovimento = 'D' THEN l.Valor ELSE -l.Valor END), 0)
                    ELSE
                        COALESCE(SUM(CASE WHEN l.TipoMovimento = 'C' THEN l.Valor ELSE -l.Valor END), 0)
                END AS SaldoActual
            FROM PlanoContas p
            LEFT JOIN LinhasLancamento l ON p.CodigoConta = l.CodigoConta
            LEFT JOIN CabecalhoLancamento c ON c.IdLancamento = l.IdLancamento
                AND ($empresa IS NULL OR c.IdEmpresa = $empresa)
                AND ($dataAte IS NULL OR c.DataLancamento <= $dataAte)
            WHERE ($classe IS NULL OR p.Classe = $classe)
              AND ($apenasMov = 0 OR p.TipoConta = 'A')
            GROUP BY p.CodigoConta, p.Designacao, p.TipoConta, p.NaturezaPredominante, p.Classe
            ORDER BY p.CodigoConta";

        cmd.Parameters.AddWithValue("$empresa", (object?)idEmpresa ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$classe", (object?)classe ?? DBNull.Value);
        cmd.Parameters.AddWithValue("$apenasMov", apenasMovimento ? 1 : 0);
        cmd.Parameters.AddWithValue("$dataAte", dataAte.HasValue
            ? dataAte.Value.ToString("yyyy-MM-dd")
            : (object)DBNull.Value);

        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            lista.Add(new SaldoContaModel
            {
                CodigoConta          = r.GetString(0),
                Designacao           = r.GetString(1),
                TipoConta            = r.GetString(2),
                NaturezaPredominante = r.GetString(3),
                Classe               = r.GetInt32(4),
                TotalDebito          = r.GetDecimal(5),
                TotalCredito         = r.GetDecimal(6),
                SaldoActual          = r.GetDecimal(7)
            });
        }

        return lista;
    }

    /// <summary>
    /// Balancete de verificação: só contas com movimento e totais de Débito/Crédito.
    /// Útil para validar se o razão está equilibrado.
    /// </summary>
    public (decimal TotalDebitos, decimal TotalCreditos, List<SaldoContaModel> Contas) ObterBalancete(
        int? idEmpresa = null,
        DateTime? dataAte = null)
    {
        var contas = ObterSaldos(idEmpresa, classe: null, apenasMovimento: true, dataAte)
            .Where(c => c.TotalDebito != 0 || c.TotalCredito != 0)
            .ToList();

        var totalD = contas.Sum(c => c.TotalDebito);
        var totalC = contas.Sum(c => c.TotalCredito);

        return (totalD, totalC, contas);
    }

    private bool ContaEDeMovimento(string codigoConta)
    {
        using var cmd = _con.CreateCommand();
        cmd.CommandText = "SELECT TipoConta FROM PlanoContas WHERE CodigoConta = $c";
        cmd.Parameters.AddWithValue("$c", codigoConta);
        var tipo = cmd.ExecuteScalar() as string;
        return tipo == "A";
    }
}
