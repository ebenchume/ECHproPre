// Ligação central à base de dados SQLite do ECHpro.
// A base fica em ProgramData\ECHpro\echpro.db (partilhada entre utilizadores da máquina).
using Microsoft.Data.Sqlite;

namespace ECHpro.Data;

public static class ConfigBaseDados
{
    public static string CaminhoBaseDados { get; } =
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "ECHpro", "echpro.db");

    /// <summary>
    /// Abre (ou cria) a ligação SQLite com WAL + foreign keys activas.
    /// </summary>
    public static SqliteConnection AbrirLigacao()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(CaminhoBaseDados)!);

        var con = new SqliteConnection($"Data Source={CaminhoBaseDados}");
        con.Open();

        using (var cmd = con.CreateCommand())
        {
            cmd.CommandText = "PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;";
            cmd.ExecuteNonQuery();
        }

        return con;
    }
}
