namespace ECHpro.Data.Models;

/// <summary>
/// Resultado do extrato/razão de uma conta do plano de contas.
/// </summary>
public sealed class SaldoContaModel
{
    public string CodigoConta { get; set; } = "";
    public string Designacao { get; set; } = "";
    public string TipoConta { get; set; } = "";           // A = Analítica, I = Integradora
    public string NaturezaPredominante { get; set; } = ""; // D ou C
    public int Classe { get; set; }
    public decimal TotalDebito { get; set; }
    public decimal TotalCredito { get; set; }
    public decimal SaldoActual { get; set; }
}
