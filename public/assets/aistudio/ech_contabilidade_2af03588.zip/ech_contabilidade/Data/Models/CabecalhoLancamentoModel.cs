namespace ECHpro.Data.Models;

/// <summary>
/// Modelo do cabeçalho de um lançamento contábil.
/// </summary>
public sealed class CabecalhoLancamentoModel
{
    public int IdLancamento { get; set; }
    public DateTime DataLancamento { get; set; }
    public string NumeroDocumento { get; set; } = "";
    public int IdDiario { get; set; }
    public string? DescricaoGeral { get; set; }
    public int IdEmpresa { get; set; } = 1;
    public List<LinhaLancamentoModel> Linhas { get; set; } = new();
}
