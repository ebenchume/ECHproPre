namespace ECHpro.Data.Models;

/// <summary>
/// Modelo de uma linha de lançamento contábil (partida dobrada).
/// </summary>
public sealed class LinhaLancamentoModel
{
    public int IdLinha { get; set; }
    public int IdLancamento { get; set; }
    public string CodigoConta { get; set; } = "";
    public string TipoMovimento { get; set; } = "";   // "D" ou "C"
    public decimal Valor { get; set; }
    public string? HistoricoEspecifico { get; set; }
}
