namespace ECHpro.Data.Models;

/// <summary>
/// Linha da Demonstração de Resultados por Natureza (DRE).
/// </summary>
public class LinhaDRE
{
    public string Rubrica { get; set; } = "";
    public string? Nota { get; set; }
    public decimal ValorAtual { get; set; }
    public bool IsSubtotal { get; set; }  // Ativa o fundo azul claro / destaque
    public bool IsTotal { get; set; }     // Destaque mais forte (resultado final)
}
