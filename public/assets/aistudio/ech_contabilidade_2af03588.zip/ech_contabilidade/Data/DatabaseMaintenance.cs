// Criação/migração e cópia de segurança da base de dados.
// Chamado pelo instalador:  ECHpro.App.exe --init-db   (instalação)
//                           ECHpro.App.exe --backup    (antes de desinstalar)
using Microsoft.Data.Sqlite;

namespace ECHpro.Data;

public static class DatabaseMaintenance
{
    /// <summary>
    /// Aplica por ordem alfabética os ficheiros db\*.sql que ainda não foram aplicados
    /// (01_schema.sql, 02_demonstracoes.sql, ...). Cada ficheiro corre numa transação
    /// e fica registado em schema_migrations, por isso é seguro chamar em todos os arranques.
    /// </summary>
    public static void EnsureCreated(string? sqlFolder = null)
    {
        sqlFolder ??= Path.Combine(AppContext.BaseDirectory, "db");
        if (!Directory.Exists(sqlFolder))
            throw new DirectoryNotFoundException($"Pasta de scripts da base de dados não encontrada: {sqlFolder}");

        using var con = ConfigBaseDados.AbrirLigacao();
        Run(con, @"CREATE TABLE IF NOT EXISTS schema_migrations (
                       nome TEXT PRIMARY KEY,
                       aplicado_em TEXT NOT NULL DEFAULT (datetime('now')))");

        foreach (var file in Directory.GetFiles(sqlFolder, "*.sql").OrderBy(Path.GetFileName, StringComparer.Ordinal))
        {
            var nome = Path.GetFileName(file);
            using (var chk = con.CreateCommand())
            {
                chk.CommandText = "SELECT 1 FROM schema_migrations WHERE nome = $n";
                chk.Parameters.AddWithValue("$n", nome);
                if (chk.ExecuteScalar() is not null) continue;
            }

            using var tx = con.BeginTransaction();
            try
            {
                using var cmd = con.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandText = File.ReadAllText(file);
                cmd.ExecuteNonQuery();

                using var reg = con.CreateCommand();
                reg.Transaction = tx;
                reg.CommandText = "INSERT INTO schema_migrations (nome) VALUES ($n)";
                reg.Parameters.AddWithValue("$n", nome);
                reg.ExecuteNonQuery();
                tx.Commit();
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw new InvalidOperationException($"Falha ao aplicar {nome}: {ex.Message}", ex);
            }
        }
    }

    /// <summary>Cópia consistente (API de backup do SQLite) para ProgramData\ECHpro\backups; mantém as últimas N.</summary>
    public static string? Backup(int manter = 30)
    {
        if (!File.Exists(ConfigBaseDados.CaminhoBaseDados)) return null;

        var pasta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ECHpro", "backups");
        Directory.CreateDirectory(pasta);
        var destino = Path.Combine(pasta, $"echpro_{DateTime.Now:yyyyMMdd_HHmmss}.db");

        using (var origem = ConfigBaseDados.AbrirLigacao())
        using (var dst = new SqliteConnection($"Data Source={destino}"))
        {
            dst.Open();
            origem.BackupDatabase(dst);
        }

        foreach (var antigo in Directory.GetFiles(pasta, "echpro_*.db").OrderByDescending(f => f).Skip(manter))
            try { File.Delete(antigo); } catch (IOException) { }
        return destino;
    }

    private static void Run(SqliteConnection con, string sql)
    { using var c = con.CreateCommand(); c.CommandText = sql; c.ExecuteNonQuery(); }
}
