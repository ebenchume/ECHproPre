// ViewModel da Folha de Salários.
// Calcula IRPS (tabela AT) e INSS (3% trabalhador + 4% empresa).
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Microsoft.Data.Sqlite;

namespace ECHpro.App.ViewModels;

public sealed class PayrollViewModel : INotifyPropertyChanged
{
    private readonly SqliteConnection _con;
    private readonly int _empresaId;

    public event PropertyChangedEventHandler? PropertyChanged;

    public ObservableCollection<FuncionarioLinha> Funcionarios { get; } = new();

    private int _ano = DateTime.Now.Year;
    public int Ano
    {
        get => _ano;
        set { if (_ano != value) { _ano = value; OnPropertyChanged(); } }
    }

    private int _mes = DateTime.Now.Month;
    public int Mes
    {
        get => _mes;
        set { if (_mes != value) { _mes = value; OnPropertyChanged(); } }
    }

    private string _estado = "rascunho";
    public string Estado
    {
        get => _estado;
        set { if (_estado != value) { _estado = value; OnPropertyChanged(); } }
    }

    private decimal _totalLiquido;
    public decimal TotalLiquido
    {
        get => _totalLiquido;
        private set { if (_totalLiquido != value) { _totalLiquido = value; OnPropertyChanged(); } }
    }

    private decimal _totalIrps;
    public decimal TotalIrps
    {
        get => _totalIrps;
        private set { if (_totalIrps != value) { _totalIrps = value; OnPropertyChanged(); } }
    }

    private decimal _totalInssEmpresa;
    public decimal TotalInssEmpresa
    {
        get => _totalInssEmpresa;
        private set { if (_totalInssEmpresa != value) { _totalInssEmpresa = value; OnPropertyChanged(); } }
    }

    public PayrollViewModel(SqliteConnection con, int empresaId)
    {
        _con = con;
        _empresaId = empresaId;
        CarregarFuncionarios();
    }

    public void CarregarFuncionarios()
    {
        Funcionarios.Clear();
        if (_empresaId == 0) return;

        using var cmd = _con.CreateCommand();
        cmd.CommandText = @"
            SELECT id, nome, salario_base, num_dependentes, inss_contribuinte
            FROM funcionario
            WHERE id_empresa = $e AND activo = 1
            ORDER BY nome";
        cmd.Parameters.AddWithValue("$e", _empresaId);

        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            var linha = new FuncionarioLinha
            {
                Id = r.GetInt32(0),
                Nome = r.GetString(1),
                SalarioBase = r.GetDecimal(2),
                NumDependentes = r.GetInt32(3),
                ContribuiInss = r.GetInt32(4) == 1
            };
            CalcularLinha(linha);
            Funcionarios.Add(linha);
        }
        ActualizarTotais();
    }

    public void CalcularLinha(FuncionarioLinha l)
    {
        var iliquido = l.SalarioBase + l.Subsidios;
        l.InssTrabalhador = l.ContribuiInss ? Math.Round(iliquido * 0.03m, 2) : 0m;
        l.InssEmpresa     = l.ContribuiInss ? Math.Round(iliquido * 0.04m, 2) : 0m;
        l.Irps            = CalcularIrps(iliquido - l.InssTrabalhador, l.NumDependentes);
        l.Liquido         = iliquido - l.InssTrabalhador - l.Irps - l.DescontosOutros;
    }

    /// <summary>
    /// Tabela simplificada de retenção mensal IRPS (AT – Lei 33/2007 alterada).
    /// Isento até ~20.250 MT. Escaloões aproximados para implementação inicial.
    /// </summary>
    public static decimal CalcularIrps(decimal baseTributavel, int dependentes)
    {
        if (baseTributavel <= 20_250m) return 0m;

        // Coeficiente marginal simplificado (versão inicial – ajustar com tabela oficial completa)
        decimal taxa = baseTributavel switch
        {
            <= 30_000m => 0.10m,
            <= 45_000m => 0.15m,
            <= 70_000m => 0.20m,
            <= 100_000m => 0.25m,
            _ => 0.32m
        };

        // Abatimento simbólico por dependente (placeholder – substituir por tabela oficial)
        var abatimento = Math.Min(dependentes, 4) * 500m;
        var imposto = Math.Max(0, (baseTributavel - 20_250m) * taxa - abatimento);
        return Math.Round(imposto, 2);
    }

    public void ActualizarTotais()
    {
        TotalLiquido     = Funcionarios.Sum(f => f.Liquido);
        TotalIrps        = Funcionarios.Sum(f => f.Irps);
        TotalInssEmpresa = Funcionarios.Sum(f => f.InssEmpresa);
    }

    public void RecalcularTudo()
    {
        foreach (var f in Funcionarios) CalcularLinha(f);
        ActualizarTotais();
    }

    private void OnPropertyChanged([CallerMemberName] string? nome = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nome));
}

public sealed class FuncionarioLinha : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    public int Id { get; set; }
    public string Nome { get; set; } = "";
    public int NumDependentes { get; set; }
    public bool ContribuiInss { get; set; } = true;

    private decimal _salarioBase;
    public decimal SalarioBase
    {
        get => _salarioBase;
        set { _salarioBase = value; OnPropertyChanged(); }
    }

    private decimal _subsidios;
    public decimal Subsidios
    {
        get => _subsidios;
        set { _subsidios = value; OnPropertyChanged(); }
    }

    private decimal _descontosOutros;
    public decimal DescontosOutros
    {
        get => _descontosOutros;
        set { _descontosOutros = value; OnPropertyChanged(); }
    }

    public decimal Irps { get; set; }
    public decimal InssTrabalhador { get; set; }
    public decimal InssEmpresa { get; set; }
    public decimal Liquido { get; set; }

    private void OnPropertyChanged([CallerMemberName] string? nome = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nome));
}
