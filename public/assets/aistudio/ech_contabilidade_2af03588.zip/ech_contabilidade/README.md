# ECHpro – Contabilidade & Recursos Humanos

Software de contabilidade e folha de salários para **Moçambique**, alinhado com o **PGC-NIRF** (Decreto 70/2009) e legislação fiscal (IRPS, INSS, IVA, IRPC).

## Estado actual (Outubro 2026)

### Já implementado
- Arranque da aplicação com modos silenciosos (`--init-db`, `--backup`)
- Sistema de migrações SQL (ficheiros em `db/*.sql`)
- Schema completo:
  - Empresa (multi-empresa preparado)
  - Plano de Contas (PGC-NIRF)
  - Diários + Lançamentos (partidas dobradas)
  - Funcionários + Folha de Salários (estrutura)
- Plano de contas base (Classes 1–8) pré-carregado
- Licenciamento simples (ficheiro local)
- Janela de activação
- Módulo **Folha de Salários** (UI + cálculo IRPS/INSS básico)

### Próximos passos recomendados
1. Gravação real da folha processada (`folha_salario` + `folha_linha`)
2. Cadastro de Empresa e Funcionários (CRUD)
3. Tabela oficial completa de retenção IRPS (AT)
4. Lançamento automático na contabilidade ao processar a folha
5. Módulos: Plano de Contas (consulta), Lançamentos manuais, IVA, Demonstrações
6. Relatórios (recibo de vencimento, mapa de remessas INSS/IRPS)

## Estrutura do projecto

```
ECHpro.App/
├── App.xaml / App.xaml.cs          # Arranque + DI
├── MainWindow.xaml(.cs)            # Navegação principal
├── Data/
│   ├── ConfigBaseDados.cs          # Ligação SQLite
│   └── DatabaseMaintenance.cs      # Migrações + backup
├── Licensing/
│   └── LicenseService.cs
├── ViewModels/
│   └── PayrollViewModel.cs
├── Views/
│   ├── PayrollPage.xaml(.cs)
│   └── ActivationWindow.xaml(.cs)
└── db/
    ├── 01_schema.sql               # Tabelas principais
    └── 02_plano_contas_pgc.sql     # Contas PGC-NIRF
```

## Requisitos
- Windows 10/11
- .NET 8 SDK
- Windows App SDK

## Comandos úteis
```bash
# Inicializar base de dados (usado pelo instalador)
ECHpro.App.exe --init-db

# Backup antes de desinstalar
ECHpro.App.exe --backup
```

## Base de dados
Localização: `%ProgramData%\ECHpro\echpro.db`  
Backups: `%ProgramData%\ECHpro\backups\`  
Logs: `%ProgramData%\ECHpro\logs\`
